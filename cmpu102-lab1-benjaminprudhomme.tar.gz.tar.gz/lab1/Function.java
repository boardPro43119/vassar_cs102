public class Function
{
    // Empty constructor
    public Function(){}
    
    public double imageOf(double x){
        return Double.NaN;
    }
    
    public double root(){
        return Double.NaN;
    }
    
    public String toString(){
        return "";
    }
}
